colors = {
    'green': 65,
    'cyan': 90,
    'orange': 43,
    'red': 1100,
    'yellow': 52
}
