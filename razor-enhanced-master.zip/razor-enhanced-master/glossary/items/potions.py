from Scripts.utilities.items import myItem

potions = {
    'keg of greater strength potions': myItem( 'keg of greater strength potions', 0x1940, 0x03B8, 'potion', 1 ),
    'bottle of toxic poison': myItem( 'bottle of toxic poison', 0x0EFB, 0x0785, 'potion', 1 ),
}
