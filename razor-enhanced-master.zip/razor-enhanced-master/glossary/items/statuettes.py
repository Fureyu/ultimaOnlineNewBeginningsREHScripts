from Scripts.utilities.items import myItem

statuettes = {
    'dread spider statuette': myItem( 'dread spider statuette', 0x25C4, 0x0000, 'statuette', 1 ),
    'lich statuette': myItem( 'lich statuette', 0x25A4, 0x0000, 'statuette', 1 ),
    'orc shaman statuette': myItem( 'orc shaman statuette', 0x25B1, 0x0000, 'statuette', 1 ),
    'slime statuette': myItem( 'slime statuette', 0x20E8, 0x0000, 'statuette', 1 ),
    'snow elemental statuette': myItem( 'snow elemental statuette', 0x25DC, 0x0000, 'statuette', 1 ),
}
