from Scripts.utilities.items import myItem

cloth = {
    'cut cloth': myItem( 'cut cloth', 0x1767, 0x07C2, 'tailoring', 10 ),
    'pile of folded besotted cloth': myItem( 'pile of folded besotted cloth', 0x1766, 0x0000, 'tailoring', 1 ),
    'piles of hides': myItem( 'piles of hides', 0x1079, 0x0000, 'tailoring', 10 ),
    'pieces of leather': myItem( 'pieces of leather', 0x1081, 0x0000, 'tailoring', 1 )
}
