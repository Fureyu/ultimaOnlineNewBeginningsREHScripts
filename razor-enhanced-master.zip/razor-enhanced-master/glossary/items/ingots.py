from Scripts.utilities.items import myItem

ingots = {
    'agapite ingot': myItem( 'agapite ingot', 0x1BF2, 0x097E, 'ingot', 0.1 ),
    'bronze ingot': myItem( 'bronze ingot', 0x1BF2, 0x06D8, 'ingot', 0.1 ),
    'copper ingot': myItem( 'copper ingot', 0x1BF2, 0x045F, 'ingot', 0.1 ),
    'dull copper ingot': myItem( 'dull copper ingot', 0x1BF2, 0x0415, 'ingot', 0.1 ),
    'golden ingot': myItem( 'golden ingot', 0x1BF2, 0x06B7, 'ingot', 0.1 ),
    'iron ingot': myItem( 'iron ingot', 0x1BF2, 0x0000, 'ingot', 0.1 ),
    'shadow iron ingot': myItem( 'shadow iron ingot', 0x1BF2, 0x0455, 'ingot', 0.1 ),
    'verite ingot': myItem( 'verite ingot', 0x1BF2, 0x07D2, 'ingot', 0.1 ),
    'valorite ingot': myItem( 'valorite ingot', 0x1BF2, 0x0544, 'ingot', 0.1 )
}
