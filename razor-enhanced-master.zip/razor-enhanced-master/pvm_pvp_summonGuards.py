while True:
    if Player.Hits < Player.HitsMax:
        Player.ChatSay( 'guards' )
    Misc.Pause( 200 )
