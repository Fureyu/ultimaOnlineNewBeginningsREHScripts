Misc.SendMessage( 'X: %i,Y: %i,Z: %i' % ( Player.Position.X, Player.Position.Y, Player.Position.Z ) )
