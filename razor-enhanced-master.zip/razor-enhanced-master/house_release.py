Player.ChatSay( 58, 'i wish to release this' )
