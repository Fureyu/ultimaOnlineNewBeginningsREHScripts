class GumpSelection:
    gumpID = None
    buttonID = None

    def __init__( self, gumpID, buttonID ):
        self.gumpID = gumpID
        self.buttonID = buttonID
