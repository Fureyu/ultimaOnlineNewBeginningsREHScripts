colors = {
    'green': 65,
    'cyan': 90,
    'red': 1100,
    'yellow': 52
}
