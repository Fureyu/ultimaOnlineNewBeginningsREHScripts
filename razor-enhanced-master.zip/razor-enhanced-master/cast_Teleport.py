Spells.CastMagery( 'Teleport' )
Target.WaitForTarget( 2000, False )
Target.TargetExecuteRelative( Player.Serial, 10 )
