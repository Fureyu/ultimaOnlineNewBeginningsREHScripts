if Player.Name == 'TheWarMage':
    Gumps.WaitForGump( 1431013363, 2000 )
    Gumps.SendAction( 1431013363, 0 )
    Items.UseItem( 0x42783F7F )
    Gumps.WaitForGump( 1431013363, 2000 )
    Gumps.SendAction( 1431013363, 24 )
