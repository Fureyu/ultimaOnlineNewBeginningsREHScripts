Player.ChatSay( 52, 'vendor buy bank guards' )
